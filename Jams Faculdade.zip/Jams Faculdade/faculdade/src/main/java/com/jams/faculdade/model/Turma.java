package com.jams.faculdade.model;

import java.util.Set;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

// Sandokam fez todo o script deste e ajustes de erro feitos pelo Augusto Koch

@Getter 
@Setter
@Entity
@Table

public class Turma {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @JoinColumn(name = "turma_id")

    @Column(name = "Nome")
    private String nome;

    @OneToMany(mappedBy = "turma" ,cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    @JsonManagedReference
    private Set<Estudante> estudantes;

    @OneToMany(mappedBy = "turma" ,cascade = CascadeType.ALL, orphanRemoval = true,fetch = FetchType.LAZY)
    @JsonManagedReference
    private Set<Disciplina> disciplinas;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "curso_id")
    @JsonBackReference("turmaReference")
    private Curso curso;

    public Turma(Long id, String nome, Set<Estudante> estudantes, Set<Disciplina> disciplinas, Curso curso) {
        this.id = id;
        this.nome = nome;
        this.estudantes = estudantes;
        this.disciplinas = disciplinas;
        this.curso = curso;
    }
}
