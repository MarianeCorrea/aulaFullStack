package com.jams.faculdade.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.jams.faculdade.model.Turma;
import com.jams.faculdade.repository.TurmaRepository;

// Sandokam fez todo o script deste e ajustes de erro feitos pelo Augusto Koch
@CrossOrigin
@RestController
@RequestMapping("/turma")
public class TurmaController {
    @Autowired
    private TurmaRepository turmaRepository;
    @GetMapping
    public List<Turma> getAllTurma() {
        return turmaRepository.findAll();
    }
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public Turma createTurma(@RequestBody Turma turma) {
        return turmaRepository.save(turma);
    }

    @DeleteMapping("/turma/{id}")
    public ResponseEntity<Turma> deleteTurma(@PathVariable Long id){
        try{
            turmaRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }    
}