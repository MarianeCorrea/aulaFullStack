package com.jams.faculdade.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jams.faculdade.model.Estudante;
import com.jams.faculdade.repository.EstudanteRepository;

// Mariane fez todo o script deste e ajustes de erro feitos pelo Augusto Koch
@CrossOrigin
@RestController
@RequestMapping("/estudante")
public class EstudanteController {
    @Autowired
    private EstudanteRepository estudanteRepository;
    @GetMapping
    public List<Estudante> getAllEstudante() {
        return estudanteRepository.findAll();
    }
    @PostMapping
    public Estudante createEstudante(@RequestBody Estudante estudante) {
        return estudanteRepository.save(estudante);
    }

    @DeleteMapping("/estudante/{id}")
    public ResponseEntity<Estudante> deleteEstudante(@PathVariable Long id){
        try{
            estudanteRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        }
        catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }    
}