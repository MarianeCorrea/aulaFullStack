package com.jams.faculdade.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jams.faculdade.model.Disciplina;

public interface DisciplinaRepository extends JpaRepository<Disciplina, Long>{
    
}
