package com.jams.faculdade.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jams.faculdade.model.Curso;

public interface CursoRepository extends JpaRepository<Curso, Long> {
    
}
